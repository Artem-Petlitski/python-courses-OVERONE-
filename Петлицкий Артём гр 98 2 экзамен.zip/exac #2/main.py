# Задание 1.

# lst_1 = [1,2,3,4,5,6,2,3,"ad","bc",'ad']
# for letter in lst_1:
#     if lst_1.count(letter) == 1:
#         print(letter)

# Задание 2.

# lst_2 = [1,2,3,4,5,6,7,1,2,3,4,3,3]
# lst_2_buffer = []
# count = 0
# for number in lst_2:
#     if lst_2.count(number) > 1 and number not in lst_2_buffer:
#         lst_2_buffer.append(number)
#         count += lst_2.count(number)//2
# print(count)
#


# Задание 3.

# C_1 = (35, 78, 21, 37, 2, 98, 6, 100, 231)
# C_2 = (45, 21, 124, 76, 5, 23, 91, 234)
# if sum(C_1) > sum(C_2):
#     print("Сумма больше в кортеже 1")
# elif sum(C_1) < sum(C_2):
#     print("Сумма больше в кортеже 2")
# else:
#     print("Сумма кортежей одинакова")
# print(
#     f"Номер максимального элемента первого кортежа - {C_1.index(max(C_1)) + 1}, индекс минимального - {C_1.index(min(C_1) + 1)}")
# print(
#     f"Номер максимального элемента второго кортежа - {C_2.index(max(C_2) + 1)}, индекс минимального - {C_2.index(min(C_2) + 1)}")

# Задание 4.

# str_4 = "An apple a day keeps the doctor away"
# dict_4 = {}
# for letter in str_4:
#     if letter not in dict_4:
#         dict_4[letter] = str_4.count(letter)
# print(dict_4)

# Задание 5.

dict_5 = {"Маффин": ["яблоки, мука", 3.23, 10], "Пирожное": ["вода, сахар", 4.02, 12]}
choice = -1
while choice != 6:
    try:
        choice = int(input("Выберите операцию:\n"
                   "1)Посмотреть описание: \n"
                   "2)Посмотреть цену: \n"
                   "3)Посмотреть количество: \n"
                   "4)Вся информация о товаре: \n"
                   "5)Покупка: \n"
                   "6)До свидания. \n"))
        if choice == 1:
            name = input("Введите название товара: ").capitalize()
            while name not in dict_5.keys():
                print("Данный товар не обнаружен")
                name = input("Введите название товара: ").capitalize()
            print(f"Состав: {dict_5[name][0]}")
        elif choice == 2:
            name = input("Введите название товара: ").capitalize()
            while name not in dict_5.keys():
                print("Данный товар не обнаружен")
                name = input("Введите название товара: ").capitalize()
            print(f"Цена : {dict_5[name][1]}")

        elif choice == 3:
            name = input("Введите название товара: ").capitalize()
            while name not in dict_5.keys():
                print("Данный товар не обнаружен")
                name = input("Введите название товара: ").capitalize()
            print(f"Количество: {dict_5[name][2]}")

        elif choice == 4:
            name = input("Введите название товара: ").capitalize()
            while name not in dict_5.keys():
                print("Данный товар не обнаружен")
                name = input("Введите название товара: ").capitalize()
            print(f"Информация о товаре: {name}\n"
              f"Состав: {dict_5[name][0]}\n"
              f"Цена : {dict_5[name][1]}\n"
              f"Количество: {dict_5[name][2]}\n")

        elif choice == 5:
            name = input("Введите название товара: ").capitalize()
            while name not in dict_5.keys():
                print("Данный товар не обнаружен")
                name = input("Введите название товара: ").capitalize()

            count = input("Введите количество")
            while count.isdigit() == False:
                count = input("Введите количество")
            count = int(count)
            while count > dict_5[name][2]:
                print("Данного количества на складе не обнаружено")
                count = input("Введите количество")
            print(f"Чек:{count * dict_5[name][1]}\n"
            f"Остаток на складе:{dict_5[name][2]-count}\n")
            dict_5[name][2]=dict_5[name][2]-count

        elif choice == 6:
            print("До свидания")
        else:
            print("Вы ввели неверное значение")

    except ValueError:
        print("Произошла ошибка")

# Задание 6.

# lst_6 = set([1,2,3,4,5,6])
# lst_new = set([1,2,3])
# print(len(lst_6 & lst_new))

# Задание 7.

# try:
#     number = int(input("Введите целое число"))
# except ValueError:
#     print("Вы ввели не число!Произошла ошибка ValueError")
# finally:
#     print("Блок сработал в любом случае")

# Задание 8.

# with open("input.txt", 'r', encoding="utf-8") as file:
#     count = 0
#     length = 0
#     for line in file:
#         line = line.split()
#         length += 1
#         count += int(line[2])
#         if int(line[2]) < 3:
#             print(f"{line[0]} {line[1]}")
# print(f"Средний балл по классу = {count/length}")
