# задача 1 Напишите функцию, которая будет принимать номер кредитной карты и
# показывать только последние 4 цифры. Остальные цифры должны заменяться
# звездочками

# def credit_card(card):
#     if len(card) != 16:
#         print("Вы ошиблись")
#     else:
#         card = "*" * 12 + card[12:]
#         print(card)
#
#
# credit_card("1111222233334444")
# задача 2 Напишите функцию, которая проверяет: является ли слово палиндромом

# def polindrom(word):
#     if word.isalpha():
#         word = word.strip().upper()
#         wordw_1 = word[::-1]
#         if wordw_1 == word:
#             print("Полиндром")
#         else:
#             print("Не полиндром")
#     else:
#         print("Вы ошиблись!")
#
#
# polindrom("Аса ")


# задача 3 Решите задачу
class Tomato():
    tomato_list = []
    id = 1
    states = {
        1: "Зеленый",
        2: "Желтый",
        3: "Красный"
    }

    def __init__(self):
        self._index = Tomato.id
        self.stadion = 1
        self.status = Tomato.states[self.stadion]
        Tomato.tomato_list.append(Tomato.id)
        Tomato.id += 1

    def get_info(self):
        print(self.status)

    def grow(self):
        self.stadion += 1
        self.status = Tomato.states[self.stadion]

    def is_ripe(self):
        if self.stadion == 3:
            print("Созрел")
        else:
            print("Не созрел")


class TomatoBush(Tomato):

    def __init__(self, count):
        self.count = count
        self.tomatoes = []
        for i in range(count):
            self.tomatoes.append(Tomato(1))

    def grow_all(self):
        for i in range(len(self.tomatoes)):
            self.tomatoes[i].grow()

    def all_are_ripe(self):
        for i in range(len(self.tomatoes)):
            if self.tomatoes[i].stadion != 3:
                print("Не все созрели")
                break
        else:
            print("Все созрели")

    def give_away_ripe(self):
        i = 0
        while i < len(self.tomatoes):
            if self.tomatoes[i].stadion == 3:
                del self.tomatoes[i]
            else:
                i += 1


class Gardener():
    stadion = 2

    status = "Не собран"

    def __init__(self, name):

        self.name = name

    def work(self, _plant, id):
        print("Садовник работает")
        if Gardener.stadion == 4:
            print("Помидор уже созрел!")
        elif Gardener.stadion == 0:
            print("Помидор уже собрали!")
        else:
            self._plant = Tomato.states[self.stadion]
            print(Gardener._plant)
            self.stadion += 1

    def harvest(self, _plant, id):
        if Gardener.status == "Не собран" and Gardener.stadion == 4:
            print("Помидор собран")
            Gardener.status = "Собран"
            Gardener.stadion = 0
        elif Gardener.stadion != 4 and Gardener.status != "Собран":
            print("Помидор не созрел")
        elif Gardener.status == "Собран" and Gardener.stadion == 0:
            print("Помидор уже собран")

    def knowledge_base(self):

        choice_1 = 0
        while choice_1 != 2:
            choice_1 = int(input('''--Выберите действие
            1)Работа с помидорами
            2)Выйти из программы
            '''))
            if choice_1 == 1:
                choice = 0
                # print(Tomato.tomato_list)
                # number = int(input("Выберите индекс помидора, с которым будет работать садовник"))
                # tomat = Tomato.tomato_list[number - 1]
                while choice != 3:
                    choice = int(input('''------Справка по садоводству-----
                    Выберите действие:
                            1)Обработать урожай.
                            2)Собрать урожай
                            3)Выйти
                            '''))
                    if choice == 1:
                        print(Tomato.tomato_list)
                        number = int(input("Выберите индекс помидора, с которым будет работать садовник"))
                        tomat = Tomato.tomato_list[number - 1]
                        Gardener.work(tomat, number)
                    elif choice == 2:
                        print(Tomato.tomato_list)
                        number = int(input("Выберите индекс помидора, с которым будет работать садовник"))
                        tomat = Tomato.tomato_list[number - 1]
                        Gardener.harvest(tomat, number)
                    elif choice == 3:
                        print("Вы вышли из работы с помидорами")
                        break

            elif choice_1 == 2:
                print("Вы вышли из программы")
                exit()


pomidor = Tomato()
pomidor_1 = Tomato()

Gardener = Gardener("Artem")
Gardener.knowledge_base()
